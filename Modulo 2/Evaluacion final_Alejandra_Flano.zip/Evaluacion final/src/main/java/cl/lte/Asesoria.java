package cl.lte;

public interface Asesoria {
    void analizarUsuario();
}
