/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package cl.unab.android.p1.ae2abp3;
/*Importar Utilitario Scanner para poder leer desde pantalla*/ 
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class AE2ABP3 {

    public static void main(String[] args) {
        
        System.out.println("Revisión de notas");
        System.out.println("");
        System.out.println("Ingrese el numero de alumnos del curso: ");
    
        /* Crear una instacia para usar la Biblioteca Scanner importada   */
        Scanner sc=new Scanner(System.in);        
        /*Declaracion de variable edad e ingreso del valor desde pantalla*/
        int num_alumnos = sc.nextInt();
        sc.nextLine();
        
        /*definicion de arreglos paralelos para trabajar datos de distinto tipos*/
        String[] nombres = new String[num_alumnos];
        int[] edades = new int[num_alumnos];
        double[] nota1 = new double[num_alumnos];
        double[] nota2 = new double[num_alumnos];
        double[] nota3 = new double[num_alumnos];
        
        /*Se realiza un cliclo con la cantidad de alumnos y asi poder ingresar los datos de cada uno de ellos*/
        for (int i = 0; i < num_alumnos ; i++){
            System.out.print ("Ingrese nombre del " + (i+1) + " Alumno : ");
            nombres[i]=sc.nextLine();
            
            System.out.print ("Ingrese edad del " + (i+1) + " Alumno ");
            edades[i] = sc.nextInt();
            
            System.out.print ("Ingrese nota 1 del " + (i+1) + " Alumno ");
            nota1[i] = sc.nextDouble();
            
            System.out.print ("Ingrese nota 2 del " + (i+1) + " Alumno ");
            nota2[i] = sc.nextDouble();
            
            System.out.print ("Ingrese nota 3 del " + (i+1) + " Alumno ");
            nota3[i] = sc.nextDouble();
            
            System.out.println("");
            sc.nextLine();
                        
        }
        
        /** ahora usaremos otro for para mostrar lo leido */
        for (int i = 0; i < num_alumnos ; i++){
            System.out.println ("El nombre del " + (i+1) + " Alumno es " + nombres[i]);
            System.out.println ("La edad del " + (i+1) + " Alumno es "+ edades[i]);
            System.out.println ("La nota 1 del " + (i+1) + " Alumno es " + nota1[i]);
            System.out.println ("La nota 2 del " + (i+1) + " Alumno es " + nota2[i]);
            System.out.println ("la nota 3 del " + (i+1) + " Alumno es " + nota3[i]);
            
            double promedio=(nota1[i] + nota2[i] + nota3[i])/3;
            if (promedio >=6.5) {
                System.out.println ("El promedio del alumno es " + promedio + " Su calificacion es Excelente");
            }
            else{
                if (promedio >=4 && promedio < 6.5) {
                    System.out.println ("El promedio del alumno es " + promedio + " Su calificacion es Aceptable");
                }
                else{
                    System.out.println ("El promedio del alumno es " + promedio + " su calificacion es Insuficiente");
                }
            }
            System.out.println("");
            
            /*Voy a ocupar esta lectura de blanco para pausar el despliegue de los alumnos*/ 
            sc.nextLine();
                        
        }
    }
}
